const express = require('express');
const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;

// 数据持久化目录
const DATA_DIR = process.env.DATA_DIR || __dirname;
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ===================== SECURITY CONFIG =====================
// 优先从环境变量读取，其次从 secrets.js 读取，最后使用空值（启动时会报错提示）
let _secrets = {};
try {
  _secrets = require('./secrets.js');
} catch (e) {
  console.warn('⚠️  未找到 secrets.js，将依赖环境变量。如需本地运行请创建 secrets.js（参考 secrets.example.js）');
}

const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || _secrets.DEEPSEEK_API_KEY || '';
const DEEPSEEK_BASE_URL = 'https://api.deepseek.com/v1/chat/completions';
const DEEPSEEK_MODEL = 'deepseek-chat';

const CHATGPT_API_KEY = process.env.CHATGPT_API_KEY || _secrets.CHATGPT_API_KEY || '';
const CHATGPT_BASE_URL = process.env.CHATGPT_BASE_URL || _secrets.CHATGPT_BASE_URL || 'https://api.openai.com/v1/chat/completions';
const CHATGPT_MODEL = process.env.CHATGPT_MODEL || _secrets.CHATGPT_MODEL || 'gpt-4o';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || _secrets.ADMIN_PASSWORD || '';

// 启动时检查必要密钥
if (!CHATGPT_API_KEY && !DEEPSEEK_API_KEY) {
  console.error('❌ 未配置任何 AI API Key！请创建 secrets.js 或设置环境变量 CHATGPT_API_KEY / DEEPSEEK_API_KEY');
}
if (!ADMIN_PASSWORD) {
  console.error('❌ 未配置管理员密码！请在 secrets.js 中设置 ADMIN_PASSWORD');
}

function adminAuth(req, res, next) {
  const token = req.query.token || req.headers['x-admin-token'];
  if (token === ADMIN_PASSWORD) return next();
  return res.status(401).json({ error: '管理员密码错误' });
}

// ===================== ASYNC WRITE QUEUE =====================
let writeQueue = Promise.resolve();
function queueWrite(filePath, data) {
  writeQueue = writeQueue.then(() => {
    return fs.promises.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8')
      .catch(err => console.error(`写入 ${filePath} 失败:`, err.message));
  });
  return writeQueue;
}

// ===================== CONFIG STORE =====================
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const DEFAULT_CONFIG = { countdownSeconds: 360, surveyClosed: false }; // 默认6分钟

let appConfig = { ...DEFAULT_CONFIG };

function loadConfig() {
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
      appConfig = { ...DEFAULT_CONFIG, ...saved };
      console.log('加载系统配置:', JSON.stringify(appConfig));
    } catch (e) {
      console.warn('config.json 解析失败:', e.message);
    }
  }
}

function saveConfig() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(appConfig, null, 2), 'utf-8');
}

// ===================== DATA STORE =====================
// submissions: [{ id, name, kindergarten, position, teachingYears, q5Answer, aiQuestions:[], status, submittedAt, lastUpdated }]
let submissions = [];
const SUBMISSIONS_FILE = path.join(DATA_DIR, 'submissions.json');

function loadSubmissionsFromDisk() {
  if (fs.existsSync(SUBMISSIONS_FILE)) {
    try {
      submissions = JSON.parse(fs.readFileSync(SUBMISSIONS_FILE, 'utf-8'));
      console.log(`从 submissions.json 加载了 ${submissions.length} 份答题记录`);
    } catch (e) {
      console.warn('submissions.json 解析失败:', e.message);
      submissions = [];
    }
  }
}

function saveSubmissionsToDisk() {
  return queueWrite(SUBMISSIONS_FILE, submissions);
}

loadSubmissionsFromDisk();

// ===================== API ROUTES =====================

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', submissionCount: submissions.length });
});

// 创建新提交（第一步：基本信息+开放作答）
app.post('/api/submit', express.json(), (req, res) => {
  try {
    const { name, kindergarten, position, teachingYears, q5Answer, q5StartAt, scenarioId, scenarioTitle, scenarioContent, phase = 'submitted' } = req.body;
    if (!name || !q5Answer) {
      return res.status(400).json({ error: '缺少姓名或作答内容' });
    }

    const now = new Date().toISOString();
    const id = 'sub_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);

    const submission = {
      id,
      name: String(name).trim(),
      kindergarten: String(kindergarten || '').trim(),
      position: String(position || '').trim(),
      teachingYears: String(teachingYears || '').trim(),
      q5Answer: String(q5Answer).trim(),
      q5StartAt: q5StartAt || null,
      scenarioId: scenarioId || null,
      scenarioTitle: scenarioTitle || '',
      scenarioContent: scenarioContent || '',
      aiQuestions: [],
      status: phase,
      createdAt: now,
      lastUpdated: now
    };

    submissions.push(submission);
    saveSubmissionsToDisk();

    console.log(`新提交: ${submission.name} (${submission.id})`);
    res.json({ success: true, id, name: submission.name });
  } catch (e) {
    console.error('提交失败:', e);
    res.status(500).json({ error: e.message });
  }
});

// 更新 AI 追问作答
app.post('/api/submit-followup', express.json(), (req, res) => {
  try {
    const { id, aiQuestions, status = 'complete' } = req.body;
    if (!id) return res.status(400).json({ error: '缺少提交ID' });

    const sub = submissions.find(s => s.id === id);
    if (!sub) return res.status(404).json({ error: '未找到提交记录' });

    sub.aiQuestions = aiQuestions || [];
    sub.status = status;
    sub.lastUpdated = new Date().toISOString();
    if (status === 'complete') sub.submittedAt = sub.lastUpdated;

    saveSubmissionsToDisk();
    console.log(`追问更新: ${sub.name} (${sub.id}) - ${status}`);
    res.json({ success: true, id });
  } catch (e) {
    console.error('追问提交失败:', e);
    res.status(500).json({ error: e.message });
  }
});

// 查询提交状态
app.get('/api/submission/:id', (req, res) => {
  const sub = submissions.find(s => s.id === req.params.id);
  if (!sub) return res.status(404).json({ error: '未找到' });
  res.json(sub);
});

// 管理端：列出所有提交
app.get('/api/submissions', adminAuth, (req, res) => {
  const list = submissions.map(s => ({
    id: s.id,
    name: s.name,
    kindergarten: s.kindergarten,
    position: s.position,
    teachingYears: s.teachingYears,
    status: s.status,
    q5Length: s.q5Answer?.length || 0,
    aiCount: s.aiQuestions?.length || 0,
    createdAt: s.createdAt,
    submittedAt: s.submittedAt,
    lastUpdated: s.lastUpdated
  }));

  res.json({
    count: submissions.length,
    completed: submissions.filter(s => s.status === 'complete').length,
    inProgress: submissions.filter(s => s.status === 'followup').length,
    submitted: submissions.filter(s => s.status === 'submitted').length,
    submissions: list
  });
});

// 管理端：删除单条提交
app.delete('/api/submissions/:id', adminAuth, (req, res) => {
  try {
    const idx = submissions.findIndex(s => s.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: '未找到该记录' });

    const removed = submissions.splice(idx, 1)[0];
    saveSubmissionsToDisk();
    console.log(`删除记录: ${removed.name} (${removed.id})`);
    res.json({ success: true, id: removed.id });
  } catch (e) {
    console.error('删除失败:', e);
    res.status(500).json({ error: e.message });
  }
});

// 管理端：批量删除
app.post('/api/submissions/batch-delete', adminAuth, express.json(), (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: '请提供要删除的记录ID列表' });
    }

    const before = submissions.length;
    const idSet = new Set(ids);
    submissions = submissions.filter(s => !idSet.has(s.id));
    const removed = before - submissions.length;

    saveSubmissionsToDisk();
    console.log(`批量删除: ${removed} 条记录`);
    res.json({ success: true, removed });
  } catch (e) {
    console.error('批量删除失败:', e);
    res.status(500).json({ error: e.message });
  }
});

// 时间格式化辅助函数
function fmtTime(isoStr) {
  if (!isoStr) return '';
  try {
    const d = new Date(isoStr);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  } catch { return ''; }
}

// 计算作答耗时（秒），start/end 为 ISO 字符串
function calcDuration(startIso, endIso) {
  if (!startIso || !endIso) return '';
  try {
    const diff = (new Date(endIso) - new Date(startIso)) / 1000;
    return Math.round(diff);
  } catch { return ''; }
}

// 计算一条提交的总 token
function calcTotalTokens(sub) {
  let total = 0;
  if (sub.aiQuestions) {
    sub.aiQuestions.forEach(q => {
      if (q.usage && q.usage.total_tokens) total += q.usage.total_tokens;
    });
  }
  return total;
}

// 按日期过滤提交记录（date 格式：YYYY-MM-DD）
function filterByDate(subs, dateStr) {
  if (!dateStr) return subs;
  return subs.filter(s => {
    const createdDate = (s.createdAt || '').slice(0, 10);
    const submittedDate = (s.submittedAt || '').slice(0, 10);
    return createdDate === dateStr || submittedDate === dateStr;
  });
}

// 管理端：导出 Excel（支持 ?date=YYYY-MM-DD 按天筛选）
app.get('/api/export/excel', adminAuth, (req, res) => {
  try {
    const dateFilter = req.query.date || '';
    const filtered = filterByDate(submissions, dateFilter);
    const headerRow = [
      '序号', '姓名', '幼儿园', '职务', '教龄',
      '情境', '情境标题',
      '作答内容', '耗时(秒)',
      'AI追问1', '回答1', '耗时(秒)',
      'AI追问2', '回答2', '耗时(秒)',
      'AI追问3', '回答3', '耗时(秒)',
      'AI追问评价（第4问）', '耗时(秒)',
      'Token消耗',
      '提交时间'
    ];
    const dataRows = filtered.map((s, i) => [
      i + 1,
      s.name,
      s.kindergarten,
      s.position,
      s.teachingYears,
      s.scenarioId || '',
      s.scenarioTitle || '',
      s.q5Answer,
      calcDuration(s.q5StartAt, s.createdAt),
      s.aiQuestions[0]?.question || '',
      s.aiQuestions[0]?.answer || '',
      calcDuration(s.aiQuestions[0]?.displayedAt, s.aiQuestions[0]?.answeredAt),
      s.aiQuestions[1]?.question || '',
      s.aiQuestions[1]?.answer || '',
      calcDuration(s.aiQuestions[1]?.displayedAt, s.aiQuestions[1]?.answeredAt),
      s.aiQuestions[2]?.question || '',
      s.aiQuestions[2]?.answer || '',
      calcDuration(s.aiQuestions[2]?.displayedAt, s.aiQuestions[2]?.answeredAt),
      s.aiQuestions[3]?.answer || '',
      calcDuration(s.aiQuestions[3]?.displayedAt, s.aiQuestions[3]?.answeredAt),
      calcTotalTokens(s) || '',
      fmtTime(s.submittedAt || s.lastUpdated)
    ]);

    const ws = XLSX.utils.aoa_to_sheet([headerRow, ...dataRows]);
    const maxCols = headerRow.length;
    ws['!cols'] = Array(maxCols).fill({}).map((_, i) => {
      const maxLen = Math.max(headerRow[i].length, ...dataRows.map(r => String(r[i] || '').length));
      return { wch: Math.min(Math.max(maxLen, 8), 60) };
    });

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '开放式情境问答');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const fileDateStr = dateFilter || new Date().toISOString().slice(0, 10);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent('开放式情境问答_' + fileDateStr)}.xlsx`);
    res.send(buf);
  } catch (e) {
    console.error('Excel 导出失败:', e);
    res.status(500).json({ error: 'Excel 生成失败: ' + e.message });
  }
});

// 管理端：导出 TXT（支持 ?date=YYYY-MM-DD 按天筛选）
app.get('/api/export/txt-all', adminAuth, (req, res) => {
  const dateFilter = req.query.date || '';
  const filtered = filterByDate(submissions, dateFilter);
  let combined = '';
  filtered.forEach((s, i) => {
    if (i > 0) combined += '\n\n' + '='.repeat(60) + '\n\n';
    combined += buildSubmissionTxt(s);
  });

  const fileDateStr = dateFilter || new Date().toISOString().slice(0, 10);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent('开放式情境问答_' + fileDateStr)}.txt`);
  res.send(combined);
});

function buildSubmissionTxt(s) {
  let content = `===== 开放式情境问答 =====\n`;
  content += `姓名：${s.name}\n`;
  content += `幼儿园：${s.kindergarten || '（未填写）'}\n`;
  content += `职务：${s.position || '（未填写）'}\n`;
  content += `教龄：${s.teachingYears || '（未填写）'}\n`;
  content += `情境：${s.scenarioTitle || s.scenarioId || '（未选择）'}\n\n`;
  content += `--- 情境内容 ---\n${s.scenarioContent || '（见问卷页面）'}\n\n`;
  const q5Dur = calcDuration(s.q5StartAt, s.createdAt);
  content += `--- 作答内容（耗时${q5Dur ? q5Dur + '秒' : '未知'}）---\n${s.q5Answer}\n`;

  if (s.aiQuestions?.length > 0) {
    content += `\n--- AI 追问 ---\n`;
    s.aiQuestions.forEach((qa, i) => {
      const dur = calcDuration(qa.displayedAt, qa.answeredAt);
      content += `追问${i + 1}：${qa.question}\n`;
      content += `回答：${qa.answer || '（未回答）'}\n`;
      content += `耗时：${dur ? dur + '秒' : '未知'}\n`;
      if (qa.usage) {
        content += `Token：${qa.usage.total_tokens}（输入${qa.usage.prompt_tokens}+输出${qa.usage.completion_tokens}）\n`;
      }
      content += `\n`;
    });
  }

  const totalTokens = calcTotalTokens(s);
  if (totalTokens > 0) {
    content += `AI Token总消耗：${totalTokens}\n\n`;
  } else {
    content += `\n`;
  }
  content += `提交时间：${fmtTime(s.submittedAt || s.lastUpdated)}\n`;
  return content;
}

// ===================== AI PROXY =====================
async function callAIProvider(name, url, apiKey, model, systemPrompt, userPrompt, timeoutMs = 28000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.8,
        max_tokens: 512
      })
    });

    if (!response.ok) {
      const err = await response.text().catch(() => '');
      throw new Error(`${name} 返回 ${response.status}: ${err.slice(0, 200)}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim();
    if (!content) throw new Error(`${name} 返回内容为空`);

    // 过滤 DeepSeek 思维链内容：移除 <think>...</think> 标签块
    content = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();

    // 若模型输出了分析段落后再跟【追问】，只保留【追问】及之后的部分
    const followUpMatch = content.match(/【追问】[\s\S]*/);
    if (followUpMatch) {
      content = followUpMatch[0].replace(/^【追问】\s*/, '').trim();
    }

    if (!content) throw new Error(`${name} 过滤后内容为空`);

    const usage = data.usage || null;
    if (usage) {
      console.log(`${name} Token: prompt=${usage.prompt_tokens}, completion=${usage.completion_tokens}, total=${usage.total_tokens}`);
    }
    return { content, usage };
  } finally {
    clearTimeout(timer);
  }
}

app.post('/api/ai-followup', express.json(), (req, res) => {
  (async () => {
    try {
      const { systemPrompt, userPrompt } = req.body;
      if (!systemPrompt || !userPrompt) {
        return res.status(400).json({ error: '缺少 systemPrompt 或 userPrompt' });
      }
      if (typeof systemPrompt !== 'string' || systemPrompt.length > 3000) {
        return res.status(400).json({ error: 'systemPrompt 格式无效或超长（上限3000字符）' });
      }
      if (typeof userPrompt !== 'string' || userPrompt.length > 5000) {
        return res.status(400).json({ error: 'userPrompt 格式无效或超长（上限5000字符）' });
      }

      try {
        const result = await callAIProvider(
          'ChatGPT', CHATGPT_BASE_URL, CHATGPT_API_KEY, CHATGPT_MODEL,
          systemPrompt, userPrompt
        );
        return res.json({ content: result.content, provider: 'chatgpt', usage: result.usage });
      } catch (gptError) {
        console.warn('ChatGPT 调用失败，尝试 DeepSeek 兜底:', gptError.message);
      }

      try {
        const result = await callAIProvider(
          'DeepSeek', DEEPSEEK_BASE_URL, DEEPSEEK_API_KEY, DEEPSEEK_MODEL,
          systemPrompt, userPrompt
        );
        return res.json({ content: result.content, provider: 'deepseek', usage: result.usage });
      } catch (dsError) {
        console.error('DeepSeek 兜底也失败:', dsError.message);
        return res.status(502).json({ error: '所有 AI 服务均不可用' });
      }
    } catch (e) {
      console.error('AI 代理调用失败:', e.message);
      res.status(502).json({ error: 'AI 服务暂时不可用' });
    }
  })();
});

// ===================== CONFIG API =====================
app.get('/api/config', (req, res) => {
  res.json({ countdownSeconds: appConfig.countdownSeconds });
});

app.post('/api/config', adminAuth, express.json(), (req, res) => {
  const { countdownSeconds } = req.body;
  if (countdownSeconds !== undefined) {
    const sec = Number(countdownSeconds);
    if (isNaN(sec) || sec < 60 || sec > 1800) {
      return res.status(400).json({ error: '倒计时时长需在60-1800秒之间' });
    }
    appConfig.countdownSeconds = sec;
    saveConfig();
    console.log('倒计时已更新:', sec, '秒');
    return res.json({ success: true, countdownSeconds: sec });
  }
  res.status(400).json({ error: '缺少 countdownSeconds 参数' });
});

// ===================== SURVEY STATUS =====================
// 公开查询问卷是否关闭（前端页面加载时检查）
app.get('/api/survey-status', (req, res) => {
  res.json({ closed: !!appConfig.surveyClosed });
});

// 管理员切换问卷开关：关闭时自动把追问中的提交标记为完成
app.post('/api/survey-status', adminAuth, express.json(), (req, res) => {
  const { closed } = req.body;
  if (typeof closed !== 'boolean') {
    return res.status(400).json({ error: '缺少 closed 参数（true/false）' });
  }

  appConfig.surveyClosed = closed;
  saveConfig();

  let autoCompleted = 0;

  if (closed) {
    // 关闭问卷：所有非 complete 状态的提交 → 直接标记完成
    const now = new Date().toISOString();
    submissions.forEach(s => {
      if (s.status !== 'complete') {
        s.status = 'complete';
        s.lastUpdated = now;
        if (!s.submittedAt) s.submittedAt = now;
        // 未填写的 AI 追问答案保留空值，维持数据完整性
        if (s.aiQuestions) {
          s.aiQuestions.forEach(q => {
            if (!q.answeredAt) q.answeredAt = now;
          });
        }
        console.log('  ✅ ' + s.name + ' (' + s.id + ')');
        autoCompleted++;
      }
    });
    saveSubmissionsToDisk();
  }

  console.log(`问卷状态: ${closed ? '已关闭' : '已开启'}，自动完成 ${autoCompleted} 条追问中记录`);
  res.json({ success: true, closed, autoCompleted });
});

// ===================== STATIC FILES =====================
app.use(express.static(__dirname));

// ===================== START =====================
loadConfig();
app.listen(PORT, () => {
  console.log(`开放式情境问答系统已启动: http://localhost:${PORT}`);
  console.log(`管理页: http://localhost:${PORT}/?admin=1`);
});
