# AI 辅助访谈问卷 —— 本地运行说明

## 文件说明

| 文件 | 说明 |
|------|------|
| `server.js` | 后端服务，含 AI 追问接口 |
| `index.html` | 前端问卷页面（单页，无需打包） |
| `prompts.js` | AI 追问提示词逻辑 |
| `package.json` | 依赖配置 |

---

## 运行步骤

**前提：电脑上需要安装 [Node.js](https://nodejs.org/)（v16 及以上）**

```bash
# 1. 安装依赖（只需第一次运行）
npm install

# 2. 启动服务
node server.js
```

启动后在浏览器打开：**http://localhost:3001**

---

## AI 接口配置

`server.js` 第 14-20 行已内置 Key，直接可用：

- **主模型**：GPT（通过 nixapi.com 中转）
  - Key：见secrets.js
  - 接口地址：`https://nixapi.com/v1/chat/completions`
  - 模型：`gpt-5.5`

- **备用模型**：DeepSeek（主模型失败时自动切换）
  - Key：见secrets.js
  - 接口地址：`https://api.deepseek.com/v1/chat/completions`

无需额外配置，`npm install && node server.js` 即可运行。

---

## 后台管理

访问 `http://localhost:3001/admin`，密码：survey2026

可查看所有答卷并导出 Excel。
