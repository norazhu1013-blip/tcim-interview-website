// ===========================
// 提示词配置文件 - 开放式情境问答与追问
// 修改此文件后，刷新页面即可生效，无需重启服务器
// ===========================

// 最后一轮收尾固定问句
const FINAL_QUESTION = '您对这个ai追问有何印象，请简单说两句。';

// ===========================
// 多情境配置
// 每条情境包含：id, category（'communication'|'game'）, title, content
// ===========================
const SCENARIOS = [
  {
    id: 'communication_1',
    category: 'communication',
    categoryLabel: '情境 1',
    title: '幼儿因被模仿创意而生气',
    content: `中班美工区，孩子们在创作"小房子"。糖糖花了很长时间，用彩纸折出了一个立体的三角形屋顶，并用彩泥在三角屋顶周围装饰了一圈，再粘上松果，非常得意地给旁边的小朋友展示："看，我做的尖尖屋顶！"过了一会儿，果果也在自己的房子上做了一个三角形屋顶，用彩泥装饰，并准备粘上松果。糖糖看到了，愣了一下，然后走到果果桌前，生气地说："这是我的创意！你不准学我！"`,
  },
  {
    id: 'game_1',
    category: 'game',
    categoryLabel: '情境 2',
    title: '幼儿对同一现象有不同猜测',
    content: `前几天下了大雨，操场角落积了一个大水洼。孩子们玩了好几天，有人用它“开船”，有人往里扔石头看水花。这两天没下雨，水洼一天天变小，今天几乎干了。几个孩子围着观察，有人问：“水跑哪儿去了？”有人说：“被太阳喝掉了。”还有人说：“是不是晚上有人把水舀走了？”几个孩子一边讨论，一边望向在旁边观察的老师。`,
  },
  {
    id: 'game_2',
    category: 'game',
    categoryLabel: '情境 3',
    title: '幼儿被指出问题后仍继续原来的搭建',
    content: `中班建构区里，几个孩子正在搭高楼。乐乐一层一层往上垒，搭到一半时，有一层积木明显歪了出去，上面的几块积木也跟着斜了，高楼随时可能倒下来。教师走过去，指着歪出去的那一层问：“这里是不是有点歪？”乐乐看了一眼，点点头说：“是。”可是他说完后，并没有调整那一层，而是又拿起一块积木继续往上摞。`,
  },
  {
    id: 'communication_2',
    category: 'communication',
    categoryLabel: '情境 4',
    title: '幼儿当小老板不收钱',
    content: `大班“小超市”游戏中，甜甜扮演“小老板”，笔笔扮演“理货员”。这天，连续几名顾客来结账时，甜甜都说“免费”，即使顾客说“我有钱！”，甜甜仍然摆摆手，不接钱。笔笔问甜甜为什么不收钱，甜甜说：“他们想买，但有人没有钱。要是收钱，他们就会不开心；少几个小朋友，就没人和我玩了。”`,
  },
];

// ===========================
// 当前选中情境（由 selectScenario() 设置）
// 默认取第一条（兼容旧版草稿恢复）
// ===========================
let _currentScenario = SCENARIOS[0];

function selectScenario(scenarioId) {
  const found = SCENARIOS.find(s => s.id === scenarioId);
  if (found) _currentScenario = found;
}

// 兼容原有代码使用的全局常量（动态代理到当前情境）
Object.defineProperty(window, 'SCENARIO_TITLE', {
  get() { return _currentScenario.title; }
});
Object.defineProperty(window, 'SCENARIO_CONTENT', {
  get() { return _currentScenario.content; }
});

// 任务提示语
const TASK_HINT = `尊敬的各位老师，您好！\n在对情境案例进行分析时，建议您可以尝试按照下列思路梳理自己的做法并完成填写：\n1、明确对象是"谁"：请指明您的做法是针对全班幼儿，还是情境中的特定幼儿（明确指出幼儿名字）。\n2、具体描述"如何做"：请具体说明您在面对某个情境时，为解决问题或实现某种目标而采用的策略、步骤。\n请避免笼统和模糊的表达。`;

// Q5 问题模板（情境名称可替换）
function buildQ5Question(scenarioTitle) {
  return `针对上述"${scenarioTitle}"，作为老师请描述你认为最有效的一种做法`;
}

// ===========================
// 逐轮追问提示词
// ===========================

// AI 角色与通用提问要求（三问共享）
const AI_ROLE = `你是一位资深的学前教育研究者，擅长教师质性访谈。

【核心任务】通过教师对幼儿园教育情境的开放式回答，不断追问，不用纠结教师实施策略的具体行为过程，目的是理解教师在该情境中的选择策略的依据与逻辑，做法背后的专业原则，需要通过你的提问激发教师表达出对策略的更多思考。

【提问要求】
1. 追问要像真实的访谈对话，不要用书面词和专业术语，用语不要像AI，不要用“卡住、接住、稳住、摸到“等词，要精简并易于理解
2. 尽量用上教师自己写过的原话
3. 问题要开放，帮助她说出更多对策略的思考，不评判对错，不引导老师的答案
4. 像一位熟悉的同事在旁边随口问她，不是考她
5. 每一轮的角度必须与前几轮不同，形成递进
6. 问题控制在2-3句话，80字以内，一次追问只能问1个问题
7. 只输出纯文本问句，不要编号，不要JSON，不要解释
8. 以"我"自称访谈者，以"您"称呼教师
9. 可以适当结合原始情境中的元素来追问，但目的是深化对教师策略的理解。`;

// 第一问 System Prompt：基于教师原始作答，提出第一个追问
function buildQ1SystemPrompt() {
  return AI_ROLE + `

【提问思路】
请理解教师的回答，基于下面四个角度分析哪个角度在他的回答里"有东西可挖"，并以该角度为切入点，问老师1个问题。
- 决策依据：教师为什么会选择这个做法？是综合了情境中的哪些信息？他为什么觉得这个做法对这个情境是最有效的？
- 概念含糊：回答中存在不能体现教师决策逻辑的概念（如尊重幼儿，适当引导），请老师解释这个概念。
- 取舍考量：这个情境有很多可以选择去做的事情，但为什么老师选择先处理这个事情？
- 教育意图：他这样做，最想让孩子获得什么？这背后是他持有怎样的儿童观或教育理念？`;
}

// 第一问 User Prompt
function buildQ1UserPrompt(teacherName, scenarioTitle, scenarioContent, q5Answer) {
  return `情境：
${scenarioContent}

问题：针对"${scenarioTitle}"，作为老师请描述你认为最有效的一种做法。

教师回答：
${q5Answer}`;
}

// ===========================
// 第二问（基于第一问+教师回答，提出追问）
// ===========================

// 第二问 System Prompt
function buildFollowUp2SystemPrompt() {
  return AI_ROLE + `

【追问思路】
请理解教师的回答，挑最值得展开的一处切入，请不要与已有问题类型重复（不要选择所有，只选择一个）：
- 隐含假设：教师在回答中可能有一个自己没说出来的判断依据，当你识别出这个判断依据时，询问教师是不是真的这样想的。
- 张力权衡：教师同时想达到的两个行为或目标（如既想不介入又想维护规则），在操作中可能会有彼此拉扯的时候。把拉扯呈现出来，请教师讲一讲是如何权衡的。`;
}

// 第二问 User Prompt
function buildFollowUp2UserPrompt(scenarioTitle, scenarioContent, q5Answer, transcript) {
  let prompt = `情境：
${scenarioContent}

问题：针对"${scenarioTitle}"，作为老师请描述你认为最有效的一种做法。

教师回答：
${q5Answer}

`;

  // transcript 目前有 1 条：第一问+回答
  if (transcript.length >= 1) {
    prompt += `【第一问】
${transcript[0].question}

【教师回答】
${transcript[0].answer}

`;
  }

  prompt += `——以上是已发生的访谈。请提出下一个追问。`;

  return prompt;
}

// ===========================
// 第三问（基于完整访谈记录，提出最后一个追问）
// ===========================

// 第三问 System Prompt
function buildFollowUp3SystemPrompt() {
  return AI_ROLE + `

【追问思路】
请理解教师的回答，挑最值得展开的一处切入，请不要与已有问题类型重复（不要选择所有，只选择一个）：
- 做法比较：结合教师现有做法，提出另一种可行做法，并描述其在同一情境中的优势，引导教师比较两种做法的差异。
- 失效延伸：基于当前情境中的具体细节（人物、事件、环境），假设教师的做法在某一点上效果不如预期，请教师分析可能的原因和调整思路。`;
}

// 第三问 User Prompt
function buildFollowUp3UserPrompt(scenarioTitle, scenarioContent, q5Answer, transcript) {
  let prompt = `情境：
${scenarioContent}

问题：针对"${scenarioTitle}"，作为老师请描述你认为最有效的一种做法。

教师回答：
${q5Answer}

`;

  // transcript 目前有 2 条：第一问+回答、第二问+回答
  transcript.forEach((item, i) => {
    const label = i === 0 ? '第一问' : '第二问';
    prompt += `【${label}】
${item.question}

【教师回答】
${item.answer}

`;
  });

  prompt += `——以上是已发生的访谈。请提出下一个追问。`;

  return prompt;
}

// ===========================
// 兼容旧接口：根据当前轮次选择合适的提示词
// ===========================
function buildFollowUpSystemPrompt(round) {
  // round: 1=生成第二问, 2=生成第三问
  if (round === 2) return buildFollowUp3SystemPrompt();
  return buildFollowUp2SystemPrompt();
}

function buildFollowUpUserPrompt(scenarioTitle, scenarioContent, transcript, q5Answer, round) {
  if (round === 2) return buildFollowUp3UserPrompt(scenarioTitle, scenarioContent, q5Answer, transcript);
  return buildFollowUp2UserPrompt(scenarioTitle, scenarioContent, q5Answer, transcript);
}
