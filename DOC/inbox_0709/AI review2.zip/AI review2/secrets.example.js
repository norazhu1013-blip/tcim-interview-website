// ===================== 密钥配置示例文件 =====================
// 使用方法：
//   将此文件复制并重命名为 secrets.js，然后填入您自己的密钥
//   命令：cp secrets.example.js secrets.js
// ===========================================================

module.exports = {
  // DeepSeek API Key（备用 AI）
  // 获取地址：https://platform.deepseek.com/
  DEEPSEEK_API_KEY: '请填入您的 DeepSeek API Key',

  // ChatGPT / 主 AI 服务 API Key
  CHATGPT_API_KEY: '请填入您的 ChatGPT API Key',

  // 主 AI 服务请求地址
  // 官方 OpenAI：https://api.openai.com/v1/chat/completions
  // 第三方中转：按对方提供的地址填写
  CHATGPT_BASE_URL: 'https://api.openai.com/v1/chat/completions',

  // 使用的模型名称，如 gpt-4o、gpt-4o-mini 等
  CHATGPT_MODEL: 'gpt-4o',

  // 管理后台登录密码（自行设置）
  ADMIN_PASSWORD: '请设置一个管理密码',

};
