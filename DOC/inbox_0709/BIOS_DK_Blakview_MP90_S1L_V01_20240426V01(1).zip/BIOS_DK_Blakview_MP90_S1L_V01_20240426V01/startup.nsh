echo -off

for %i in fs0 fs1 fs2 fs3 fs4 fs5 fs6
	if exist %i:\%0 then 
		%i:
		Fpt(6).efi -f MP90_S1L_V01_x64.bin
		
	else
	echo not find %i
	endif
endfor
:EOF
